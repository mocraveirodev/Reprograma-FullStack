import React from 'react'
import './QuemSomos.css'

function QuemSomos() {
  return (
    <main className="quem-somos">
      <h1>Quem somos</h1>
      <p>
        Try to jump onto window and fall while scratching at wall eat from dog's food eat too 
        much then proceed to regurgitate all over living room carpet while humans eat dinner lick 
        left leg for ninety minutes, still dirty. Sit on the laptop lick the plastic bag. 
      </p>
    </main>
  )
}

export default QuemSomos