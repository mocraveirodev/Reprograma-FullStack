import React from 'react'
import './Contato.css'

function Contato() {
  return (
    <main className="contato">
      <h1>Contato</h1>
      <p>
        Try to jump onto window and fall while scratching at wall eat from dog's food eat too 
        much then proceed to regurgitate all over living room carpet while humans eat dinner lick 
        left leg for ninety minutes, still dirty. Sit on the laptop lick the plastic bag. 
      </p>
    </main>
  )
}

export default Contato