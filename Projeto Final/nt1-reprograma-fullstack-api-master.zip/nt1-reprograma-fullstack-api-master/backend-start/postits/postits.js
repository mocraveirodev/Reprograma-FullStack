const postits = [
  {
    id: 1,
    title: 'Tarefas de casa',
    description: 'Lavar roupa\n Lavar louça \n Ir ao mercado'
  },
  {
    id: 2,
    title: 'Lista de mercado',
    description: 'Arroz\n Feijão\n Milho'
  },
  {
    id: 3,
    title: 'Estudar para prova',
    description: 'Ler livro "Os segredos do Ninja Javascript"'
  }
];

module.exports = postits;
